/* eslint-disable no-unused-vars */
import React from "react";

export default function Background() {
  return <div className=" w-full h-36 bg-myAccent absolute -z-40"></div>;
}