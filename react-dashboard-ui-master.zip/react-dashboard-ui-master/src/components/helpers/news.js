import pic from "../../assets/img1.png";
import pic2 from "../../assets/img2.png";
import pic3 from "../../assets/img3.png";
import pic4 from "../../assets/img4.png";

const picArr = [pic, pic2, pic3, pic4];

const news = [
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 1`,
    body: `The market capitalisation of Indian stocks crossed US$4.5 trillion in January`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 1`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 1`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 1`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 2`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 2`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 2`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 2`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 3`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 3`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 3`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 3`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 4`,
    body: `Lorem ipsum dolor sit amet`,
  },

  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 4`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 4`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 4`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 5`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 5`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 5`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 5`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 6`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 6`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 6`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 6`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 7`,
    body: `Lorem ipsum dolor sit amet`,
  },

  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 7`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 7`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 7`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 8`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 8`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 8`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 8`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 9`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 9`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 9`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 9`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 10`,
    body: `Lorem ipsum dolor sit amet`,
  },

  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 10`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 10`,
    body: `Lorem ipsum dolor sit amet`,
  },
  {
    imgurl: picArr[Math.floor(Math.random() * 4)],
    headline: `Lorem ipsum dolor sit amet 10`,
    body: `Lorem ipsum dolor sit amet`,
  },
];

const len = news.length;

export default news;
export { len };