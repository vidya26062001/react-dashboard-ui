/* eslint-disable no-unused-vars */
import React from "react";

export default function BlankPage() {
  return (
    <div className="w-full h-dvh flex justify-center items-center">
      <p>Thank You</p>
    </div>
  );
}